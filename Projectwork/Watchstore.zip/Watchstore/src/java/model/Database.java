/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.xml.transform.Result;

/**
 *
 * @author kursi
 */
public class Database {
    Connection con=null;
    Statement st=null;
    Result res=null;
    private boolean result;
    public Database()
    {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("driver load");
        } catch (ClassNotFoundException ex)
        {
      ex.printStackTrace();    
            
// Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public boolean validate(String Email,String Password) throws SQLException{
        String nameData=null,passData=null;
        try{
        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/watch","root","1234");
        String query="select email,password from signup where email= ? and password= ?";
        PreparedStatement pst=con.prepareStatement(query);
//        st=con.createStatement();
      pst.setString(1, Email);
      pst.setString(2, Password);
      ResultSet rst=pst.executeQuery();
        while(rst.next()){
           nameData=rst.getString("email");
           passData=rst.getString("password");
        }
        
        } catch(Exception ex)
        {
       System.out.println("exception" +ex);
        }           
           if(Password.equals(passData)&&Email.equals(nameData))
            {
                System.out.println("success");
                return true;
            }
            else
            {
                System.out.println("fail");
                return false;
            }
            
        }

 public boolean insertData(String name,String email,String mobile,String password) throws SQLException
    {
        
       // boolean returns=false;
      con=DriverManager.getConnection("jdbc:mysql://localhost:3306/watch","root","1234");
        //st= con.createStatement();
        
        String myQuery="insert into signup(name,email,mobile,password) values(?,?,?,?)";
        
        PreparedStatement pst=con.prepareStatement(myQuery);
        pst.setString(1, name);
        pst.setString(2, email);
        pst.setString(3, mobile);
        pst.setString(4, password);
          
        int data=pst.executeUpdate();
      
        if(data>0)
        { 
              result=true;
              System.out.println("success");
            
        }
        else
        {
            System.out.println("errrrrrr");
            return result;
        }
        return result;
        }

public ArrayList<String[]> getRecordwatches() throws SQLException//for Laptops for admin view
   {
       
       ArrayList<String []>  recordList= new ArrayList<String []>();
        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/watch","root","1234");
        
        int id;
        String brand,model,color,gender,warrenty,image;
       int price;
       String Query="Select * from modelwatch";//i
               
       
       st= con.createStatement();
       ResultSet rst= st.executeQuery(Query);
       
       while(rst.next())
       {
           
           id=rst.getInt(1);
           brand=rst.getString(2);
           model=rst.getString(3);
           color=rst.getString(4);
           gender=rst.getString(5);
           price=rst.getInt(6);
           warrenty=rst.getString(7);
           image=rst.getString(8);
           
          String data[]=new String[15];
          data[0]=Integer.toString(id);
           data[1]=brand;
           data[2]=model;
           data[3]=color;
           data[4]=gender;
           data[5]=Integer.toString(price);
           data[6]=warrenty;
           data[7]=image;
           recordList.add(data); //  all array into list 
       
       
       
       }
       return recordList;
       
}
public ArrayList<String[]> getRecord4(String id) throws SQLException
   {
       String dataname;
       ArrayList<String []>  recordList2= new ArrayList<String []>();
        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/watch","root","1234");
        
      // int id;
       String brand,model,color,gender,price,warrenty,image;
       
       String Query="Select * from modelwatch where id='"+id+"'";//id for matching
               
       
       st= con.createStatement();
       ResultSet rst= st.executeQuery(Query);
       
       while(rst.next())
       {
           dataname=rst.getString("id");
         if(id.equals(dataname))
         {
           brand=rst.getString(2);
           model=rst.getString(3);
           color=rst.getString(4);
           gender=rst.getString(5);
           price=rst.getString(6);
           warrenty=rst.getString(7);
           
                    
          String data[]=new String[10];
           data[0]=brand;
           data[1]=model;
           data[2]=color;
           data[3]=gender;
           data[4]=price;
           data[5]=warrenty;
           
           recordList2.add(data); //  all array into list 
         }
   }     
       return recordList2;
}
}